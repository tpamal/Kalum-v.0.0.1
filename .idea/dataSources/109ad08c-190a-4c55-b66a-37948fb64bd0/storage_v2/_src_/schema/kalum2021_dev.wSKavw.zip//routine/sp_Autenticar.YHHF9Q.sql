create
    definer = root@localhost procedure sp_Autenticar(IN _username varchar(64), IN _password varchar(128))
BEGIN
SELECT
        u.id,
        u.username,
        u.password,
        u.enable,
        u.nombres,
        u.apellidos,
        u.email,
        u.telefono,
        u.direccion
from usuario_app u where u.username = _username and u.password = md5(_password);
end;

