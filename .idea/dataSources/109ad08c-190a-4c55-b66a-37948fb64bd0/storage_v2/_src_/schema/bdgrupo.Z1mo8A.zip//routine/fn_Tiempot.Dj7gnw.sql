create
    definer = root@localhost function fn_Tiempot(valor1 date) returns int
begin
    
    declare tiempo int default 0;
    
    set tiempo  =TIMESTAMPDIFF(year,valor1, curdate()) ;

    
    return tiempo;
    end;

