create
    definer = root@localhost procedure sp_Ingresaregion(IN codigoregion int, IN nombre varchar(40))
begin
    insert into  region(codigoregion, nombre)
		value(codigoregion, nombre);
	
    end;

