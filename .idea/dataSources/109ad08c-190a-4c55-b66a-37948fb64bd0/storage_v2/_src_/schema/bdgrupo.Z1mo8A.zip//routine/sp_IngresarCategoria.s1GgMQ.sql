create
    definer = root@localhost procedure sp_IngresarCategoria(IN codigoCategoria int, IN nombre varchar(40),
                                                            IN Salario_Base decimal(34, 5))
begin
		insert into categoria(codigoCategoria, nombre, Salario_Base)
				values(codigoCategoria, nombre, Salario_Base);
        
    end;

