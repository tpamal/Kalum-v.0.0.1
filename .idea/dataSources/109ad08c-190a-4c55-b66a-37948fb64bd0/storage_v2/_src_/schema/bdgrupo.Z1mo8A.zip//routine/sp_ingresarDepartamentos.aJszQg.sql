create
    definer = root@localhost procedure sp_ingresarDepartamentos(IN CodigoDepartamento int, IN nombre varchar(100),
                                                                IN CodigoOficina int, IN CodigoCategoria int,
                                                                IN CodigoRegion int)
begin
		insert into departamento(CodigoDepartamento, nombre, CodigoOficina, CodigoCategoria, CodigoRegion)
			value(CodigoDepartamento, nombre, CodigoOficina, CodigoCategoria, CodigoRegion);
    
    end;

