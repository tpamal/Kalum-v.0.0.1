create
    definer = root@localhost procedure sp_IngresarEmpleado(IN DPI bigint, IN Nombres varchar(40),
                                                           IN apellidos varchar(40), IN Fecha_de_Nacimiento date,
                                                           IN Fecha_de_contratacion date)
begin
		insert into  empleados(DPI, Nombres, apellidos, Fecha_de_Nacimiento, Fecha_de_contratacion)
			values(DPI, Nombres, apellidos, Fecha_de_Nacimiento, Fecha_de_contratacion);
								
    end;

