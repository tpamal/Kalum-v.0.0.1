create
    definer = root@localhost function fn_Aumento(valor1 int, valor2 int) returns decimal(10, 2)
begin
		
		declare multiplicacion decimal(10,2) default 0; 
        declare mensaje decimal(10,2) default valor1;
        declare contador int default 0;
        declare guardar int;
               
        set multiplicacion= (2*valor1)/100;
        repeat
        
		 set contador=contador+1;
        set mensaje= mensaje + multiplicacion;
		
        until contador=valor2 end repeat;
        return mensaje;
    end;

