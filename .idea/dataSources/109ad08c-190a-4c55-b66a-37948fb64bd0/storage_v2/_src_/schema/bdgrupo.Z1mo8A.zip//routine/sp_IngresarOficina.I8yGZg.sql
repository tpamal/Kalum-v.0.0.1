create
    definer = root@localhost procedure sp_IngresarOficina(IN CodigoOficina int, IN telefono int, IN DPI bigint)
begin
		insert into oficina(CodigoOficina, telefono, DPI)
			values(CodigoOficina, telefono, DPI);
    end;

