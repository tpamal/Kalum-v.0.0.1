create
    definer = root@localhost function fn_Edad(valor1 date) returns int
begin
    
    declare edad int default 0;
    
    set edad  =TIMESTAMPDIFF(year,valor1, curdate()) ;

    
    return edad;
    end;

